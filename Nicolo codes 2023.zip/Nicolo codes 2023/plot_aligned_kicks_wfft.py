#!/usr/bin/env python
# coding: utf-8

# In[1]:


# è lo stesso codice che usavamo in C++ riscritto in python

import ROOT


# In[1]:


#creo i Tfile e plotto gli 8 kick su Canvas diverse

import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick1",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick1.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick1_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick1_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick1.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[8]:


'''#check per vedere se ci sono infiniti nel csv

import os

def find_infinity_in_folder(folder_path):
    for filename in os.listdir(folder_path):
        if filename.endswith(".csv"):
            file_path = os.path.join(folder_path, filename)
            print(f"Checking {filename}...")
            with open(file_path, 'r') as file:
                line_number = 0
                for line in file:
                    if '∞' in line:
                        print(f"In {filename}, Line {line_number}: {line.strip()}")
                    line_number += 1
            print("\n")

csv_folder_path = "/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick1"
find_infinity_in_folder(csv_folder_path)
'''


# In[10]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick2",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick2.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick2_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick2_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick2.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[11]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick3",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick3.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick3_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick3_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick3.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[12]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick4",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick4.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick4_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick4_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick4.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[13]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick5",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick5.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick5_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick5_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick5.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[14]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick6",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick6.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick6_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick6_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick6.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[15]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick7",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick7.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick7_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick7_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick7.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[16]:


import os
import ROOT

def plot_aligned_kicks_wfft(folder="/home/nicolo/FD_R0_analyses/test/FD_R0_SecondPass/Kick8",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    Npoints = 3000
    tstart = -5.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Voltage [mV]", Npoints, tstart, tend)
    h2_trace = ROOT.TH2F("h2_trace", "kicker trace", Npoints, tstart, tend, 1060, -160, 900)
    g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                time, A, B, D, avgC = map(float, line.split(','))
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if time < 0.5:
                    offset += avgC
                    off += 1

        offset = offset / (1.0 * off)

        for time, avgC in trace:
            g_trace.Fill(time - max_time, (avgC - offset))
            h2_trace.Fill(time - max_time, (avgC - offset))
            g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

        fi += 1

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-160, 900)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick8.png"))

    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "Kick8_colz.png"))

    c_trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick8_norm.png"))

    fout = ROOT.TFile(os.path.join(output_folder, "Kick8.root"), "recreate")
    g_trace.Write()
    h2_trace.Write()
    g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[50]:


# Plotto gli 8 kick sulla stessa Canvas per confrontarli tra loro

def plot_allkicks(output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True

    filein1 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick1.root")
    filein1.cd()
    g_trace1 = filein1.Get("trace")
    
    filein2 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick2.root")
    filein2.cd()
    g_trace2 = filein2.Get("trace")
    
    filein3 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick3.root")
    filein3.cd()
    g_trace3 = filein3.Get("trace")
    
    filein4 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick4.root")
    filein4.cd()
    g_trace4 = filein4.Get("trace")
    
    filein5 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick5.root")
    filein5.cd()
    g_trace5 = filein5.Get("trace")
    
    filein6 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick6.root")
    filein6.cd()
    g_trace6 = filein6.Get("trace")

    filein7 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick7.root")
    filein7.cd()
    g_trace7 = filein7.Get("trace")
    
    filein8 = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick8.root")
    filein8.cd()
    g_trace8 = filein8.Get("trace")




    a_trace = ROOT.TCanvas()
    g_trace1.GetYaxis().SetRangeUser(-180,900)
    g_trace1.SetMarkerColor(ROOT.kBlack)
    g_trace1.SetLineColor(ROOT.kBlack)
    g_trace1.SetLineWidth(2)
    g_trace1.Draw("HIST L")    #con E nella parentesi di draw si mettono gli errori
    g_trace2.SetMarkerColor(ROOT.kRed)
    g_trace2.SetLineColor(ROOT.kRed)
    g_trace2.SetLineWidth(2)
    g_trace2.Draw("HIST SAME")
    g_trace3.SetMarkerColor(ROOT.kOrange)
    g_trace3.SetLineColor(ROOT.kOrange)
    g_trace3.SetLineWidth(2)
    g_trace3.Draw("HIST SAME")
    g_trace4.SetMarkerColor(ROOT.kPink)
    g_trace4.SetLineColor(ROOT.kPink)
    g_trace4.SetLineWidth(2)
    g_trace4.Draw("HIST SAME")
    g_trace5.SetMarkerColor(ROOT.kGreen)
    g_trace5.SetLineColor(ROOT.kGreen)
    g_trace5.SetLineWidth(2)
    g_trace5.Draw("HIST SAME")
    g_trace6.SetMarkerColor(ROOT.kBlue)
    g_trace6.SetLineColor(ROOT.kBlue)
    g_trace6.SetLineWidth(2)
    g_trace6.Draw("HIST SAME")
    g_trace7.SetMarkerColor(ROOT.kTeal+4)
    g_trace7.SetLineColor(ROOT.kTeal+4)
    g_trace7.SetLineWidth(2)
    g_trace7.Draw("HIST SAME")
    g_trace8.Draw("HIST SAME")
    g_trace8.SetLineWidth(2)
    xl1 = 0.05 
    yl1 = 0.75
    xl2 = xl1+0.3
    yl2 = yl1+0.125
    leg = ROOT.TLegend(xl1,yl1,xl2,yl2)
    leg.AddEntry(g_trace1,"bunch1","l")
    leg.AddEntry(g_trace2,"bunch2","l")
    leg.AddEntry(g_trace3,"bunch3","l")
    leg.AddEntry(g_trace4,"bunch4","l")
    leg.AddEntry(g_trace5,"bunch5","l")
    leg.AddEntry(g_trace6,"bunch6","l")
    leg.AddEntry(g_trace7,"bunch7","l")
    leg.AddEntry(g_trace8,"bunch8","l")
    leg.Draw()
    a_trace.Draw()
    if SaveFigs:
        a_trace.SaveAs(os.path.join(output_folder, "allkicks_R0_SecondPass.png"))
        a_trace.SaveAs(os.path.join(output_folder, "allkicks_R0_SecondPass.root"))

    fout = ROOT.TFile(os.path.join(output_folder, "allkicks_R0_SecondPass.root"), "recreate")
    g_trace1.Write()
    g_trace2.Write()
    g_trace3.Write()
    g_trace4.Write()
    g_trace5.Write()
    g_trace6.Write()
    g_trace7.Write()
    g_trace8.Write() 
    a_trace.Write()
    fout.Close() 
    
plot_allkicks()


# In[49]:


# confronto il kick nella configurazione R0 con quello nella configurazione R1 dopo il secondo giro di misure di R0

#include <dirent.h>

def kick_comparison(output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass"):

    SaveFigs = True;

    filein1=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick1.root")
    filein1.cd()
    g_trace1 = filein1.Get("trace")

    filein2=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R1/Kick1_20us_R1.root")
    filein2.cd()
    g_trace2 = filein2.Get("trace")
    
    b_trace = ROOT.TCanvas()
    g_trace1.GetYaxis().SetRangeUser(-180,900)
    g_trace1.SetMarkerColor(ROOT.kBlack)
    g_trace1.SetLineColor(ROOT.kBlack)
    g_trace1.SetLineWidth(2)
    g_trace1.Draw("H")        #con E nella parentesi di draw si mettono gli errori
    g_trace2.SetMarkerColor(ROOT.kRed)
    g_trace2.SetLineColor(ROOT.kRed)
    g_trace2.SetLineWidth(2)
    g_trace2.Draw("SAME")  
    xl1=0.05
    yl1=0.75
    xl2=xl1+0.3
    yl2=yl1+0.125
    leg = ROOT.TLegend(xl1,yl1,xl2,yl2)
    leg.AddEntry(g_trace1,"Kick1_R0","l")
    leg.AddEntry(g_trace2,"Kick1_R1","l")
    leg.Draw()
    b_trace.Draw()
    if SaveFigs:
        b_trace.SaveAs(os.path.join(output_folder, "R0-R1_comparison_secondpass.png"))
        b_trace.SaveAs(os.path.join(output_folder, "R0_R1_comparison_secondpass.root"))
  
  
    fout = ROOT.TFile(os.path.join(output_folder, "R0_R1_comparison_secondpass.root"), "recreate")
    g_trace1.Write()
    g_trace2.Write()
    b_trace.Write()
    fout.Close()
kick_comparison()


# In[25]:


#simulation kick analysis
import csv
import os
import ROOT

def plot_aligned_kicks_wfft(folder="home/nicolo/FD_R0_analyses/test/Kicks_Simulation",
                            output_folder="/home/nicolo/FD_R0_analyses/test/analysis_Kicks_Simulation"):

    SaveFigs = True

    Npoints = 10001
    tstart = -2.0
    tend = 20.0
    dt = (tend - tstart) / Npoints

    g_trace = ROOT.TProfile("trace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)
    #g_traceNorm = ROOT.TProfile("Normtrace", "Trace;Time [us];Amplitude Normalized", Npoints, tstart, tend)

    file_path = os.path.join('/home/nicolo/FD_R0_analyses/test/Kicks_Simulation', 'KickerPulse_Run3b_Run4_Normalized.csv')

    if os.path.exists(file_path):
        with open(file_path, 'r') as csv_file:
            csv_reader = csv.reader(csv_file)

    trace = []
    max_time = 0
    max_amplitude = 0
    offset = 0
    off = 0

    with open(file_path, 'r') as file:
        for _ in range(1):
            file.readline()

        for line in file:
            time, avgC = map(float, line.split(','))
            time = time/1000
            #avgC = avgC * 1000
            trace.append((time, avgC))
            '''if avgC > max_amplitude:
                max_amplitude = avgC
                max_time = time
            if time < 2.0:
                offset += avgC
                off += 1

    offset = offset / (1.0 * off)'''

    for time, avgC in trace:
        g_trace.Fill(time, avgC)
        #g_trace.Fill(time - max_time, (avgC - offset))
        #g_traceNorm.Fill(time - max_time, (avgC - offset) / (max_amplitude - offset))

    c_trace = ROOT.TCanvas()
    g_trace.GetYaxis().SetRangeUser(-0.4,1.5)
    g_trace.Draw("HIST L")
    if SaveFigs:
        c_trace.SaveAs(os.path.join(output_folder, "Kick1_Sim.png"))

    '''trace_norm = ROOT.TCanvas()
    g_traceNorm.GetYaxis().SetRangeUser(-0.4, 1.2)
    g_traceNorm.Draw("HIST L")
    if SaveFigs:
        c_trace_norm.SaveAs(os.path.join(output_folder, "Kick1_Sim_norm.png"))'''

    fout = ROOT.TFile(os.path.join(output_folder, "Kick1_Sim.root"), "recreate")
    g_trace.Write()
    #g_traceNorm.Write()
    fout.Close()

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_aligned_kicks_wfft()


# In[26]:


#normalized kick1 comparison with simulation
import ROOT
import os

def kick_comparison(output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_Kicks_Simulation"):

    SaveFigs = True;

    filein1=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R0_SecondPass/Kick1.root")
    filein1.cd()
    g_trace1 = filein1.Get("Normtrace")

    filein2=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_R1/Kick1_20us_R1.root")
    filein2.cd()
    g_trace2 = filein2.Get("Normtrace")
    
    filein3=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_Kicks_Simulation/Kick1_Sim.root")
    filein3.cd()
    g_trace3 = filein3.Get("trace")
    
    
    
    b_trace = ROOT.TCanvas()
    g_trace1.GetYaxis().SetRangeUser(-0.8,1.5)
    g_trace1.SetMarkerColor(ROOT.kBlack)
    g_trace1.SetLineColor(ROOT.kBlack)
    g_trace1.SetLineWidth(2)
    g_trace1.Draw("H")        #con E nella parentesi di draw si mettono gli errori
    g_trace2.SetMarkerColor(ROOT.kRed)
    g_trace2.SetLineColor(ROOT.kRed)
    g_trace2.SetLineWidth(2)
    g_trace2.Draw("SAME")
    g_trace3.SetMarkerColor(ROOT.kBlue)
    g_trace3.SetLineColor(ROOT.kBlue)
    g_trace3.SetLineWidth(2)
    g_trace3.Draw("SAME")  
    xl1=0.05
    yl1=0.75
    xl2=xl1+0.3
    yl2=yl1+0.125
    leg = ROOT.TLegend(xl1,yl1,xl2,yl2)
    leg.AddEntry(g_trace1,"Kick1_R0_norm","l")
    leg.AddEntry(g_trace2,"Kick1_R1_norm","l")
    leg.AddEntry(g_trace3,"Kick_Simulation","l")
    leg.Draw()
    b_trace.Draw()
    if SaveFigs:
        b_trace.SaveAs(os.path.join(output_folder, "Sim_comparison_normalized.png"))
        b_trace.SaveAs(os.path.join(output_folder, "Sim_comparison_normalized.root"))
  
  
    fout = ROOT.TFile(os.path.join(output_folder, "Sim_comparison_normalized.root"), "recreate")
    g_trace1.Write()
    g_trace2.Write()
    g_trace3.Write()
    b_trace.Write()
    fout.Close()
kick_comparison()


# In[ ]:




