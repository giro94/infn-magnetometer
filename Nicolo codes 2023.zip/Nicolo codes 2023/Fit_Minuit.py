#!/usr/bin/env python
# coding: utf-8

# In[47]:


import ROOT
import numpy as np
import array
import pandas as pd
import matplotlib.pyplot as plt
from scipy.fft import rfft,rfftfreq
from iminuit import cost, Minuit


# In[48]:


#definisco la funzione per creare un istogramma, la funzione per fare il fit e il metodo minuit

def get_bunch(g_trace, profile, time_min, time_max):
    start_bin = g_trace.FindBin(time_min)
    end_bin = g_trace.FindBin(time_max)
    '''numBins = end_bin - start_bin
    xMin = g_trace.GetBinCenter(start_bin)
    xMax = g_trace.GetBinCenter(end_bin)
    profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)'''
    for bin_index in range(start_bin, end_bin + 1):
        bin_content = g_trace.GetBinContent(bin_index)
        bin_error = g_trace.GetBinError(bin_index)
        if bin_content == 0:
            prev_bin_content = g_trace.GetBinContent(bin_index - 1)
            next_bin_content = g_trace.GetBinContent(bin_index + 1)
            avg_bin_content = (prev_bin_content + next_bin_content) / 2
            bin_content = avg_bin_content
        profile.SetBinContent(bin_index - start_bin + 1, bin_content)
        profile.SetBinError(bin_index - start_bin + 1, bin_error)
    return profile
    
'''def residual_graph(profile, fit_func, TimeStartFit, TimeEndFit):
    start_bin_res = profile.FindBin(TimeStartFit)
    end_bin_res = profile.FindBin(TimeEndFit)
    graph_res = ROOT.TGraphErrors()
    graph_res.GetXaxis().SetLimits(0.03, 1)
    for bin_index in range(start_bin_res, end_bin_res + 1):
        x_val = profile.GetBinCenter(bin_index)
        y_obs = profile.GetBinContent(bin_index)
        y_fit = fit_func.Eval(x_val)
        residual = y_obs - y_fit
        graph_res.SetPoint(bin_index - start_bin_res, x_val, residual)
        graph_res.SetPointError(bin_index - start_bin_res, 0, profile.GetBinError(bin_index))
    ROOT.TCanvas
    return graph_res'''

def residual_graph(profile, fit_func, optimized_parameters, TimeStartFit, TimeEndFit,
                   xlim_inf = None, xlim_sup = None, ylim_inf = None, ylim_sup = None, b = None):
    x_val, y_obs, y_fit, y_err, residual = np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
    start_bin_res = profile.FindBin(TimeStartFit)
    end_bin_res = profile.FindBin(TimeEndFit)
    for bin_index in range(start_bin_res, end_bin_res + 1):
        x_val = np.append(x_val, profile.GetBinCenter(bin_index))
        y_obs = np.append(y_obs, profile.GetBinContent(bin_index))
        y_err = np.append(y_err, profile.GetBinError(bin_index))
    y_fit = fit_func(x_val, *optimized_params)
    residual = np.append(residual, y_obs - y_fit)
    residual_plot = plt.errorbar(x_val, residual, y_err, fmt="ok", color='grey', label="data", markersize=3, capsize=0.2, zorder = 2)
    plt.axhline(0, ls='--', color='red',linewidth=3.0, zorder=3)
    plt.title(f'Residual Bunch {b}')
    plt.xlabel('Time(ms)')
    plt.ylabel('Residual')
    if xlim_inf is not None and xlim_sup is not None:
        plt.xlim(xlim_inf, xlim_sup)
    if ylim_inf is not None and ylim_sup is not None:
        plt.ylim(ylim_inf, ylim_sup)
    plt.grid(True)
    plt.show()
    return residual_plot


def ExpSin_Func(x, A, tau, B, w, phi, C):
    return A*np.exp(-x/tau)+B*np.sin(w*x+phi)+C

def total_func(x, A, tau, B, w, phi, C, w2, phi2, D, w3, phi3, E):
    return A*np.exp(-x/tau)+B*np.sin(w*x+phi)+C*np.sin(w2*x+phi2)+D*np.sin(w3*x+phi3)+E

'''def total_func(x, A, tau, B, w, phi, C, w2, phi2, D, w3, phi3, E, w4, phi4, F, w5, phi5, G):
    return A*np.exp(-x/tau)+B*np.sin(w*x+phi)+C*np.sin(w2*x+phi2)+D*np.sin(w3*x+phi3)+E*np.sin(w4*x+phi4)+F*np.sin(w5*x+phi5)+G'''

def sin_func(x, A, w, phi):
    return A*np.sin(w*x+phi)

def exp_func(x, A, tau, C):
    return A*np.exp(-x/tau)+C

def ExpSinDecay_Func(x, A, tau, B, tau2, w, phi, C, w2, phi2, D, w3, phi3, E):
     return A*np.exp(-x/tau)+B*np.exp(-x/tau2)*np.sin(w*x+phi)+C*np.sin(w2*x+phi2)+D*np.sin(w3*x+phi3)+E
    
'''def ExpSin_Func(x, A, tau, B, w, phi, C, w2, phi2, D):
    return (A/tau)*np.exp(-x/tau)+B*np.sin(w*x+phi)+C*np.sin(w2*x+phi2)+D'''

def Fit_Visualize(x, y, y_fit, y_err, xlim_inf = None, xlim_sup = None, ylim_inf = None, ylim_sup = None, b=None): #b deve essere l'indice del bunch
    plt.figure(figsize=(8, 6))
    plt.plot(x, y_fit, ls="--", color='red', label="fit", linewidth=3.0, zorder = 3)
    plt.errorbar(x, y, y_err, fmt="ok", color = 'grey', label="data", markersize=3, capsize=0.2, zorder = 2)
    if xlim_inf is not None and xlim_sup is not None:
        plt.xlim(xlim_inf, xlim_sup)
    if ylim_inf is not None and ylim_sup is not None:
        plt.ylim(ylim_inf, ylim_sup)
    plt.title(f'Fit Bunch {b}')
    plt.xlabel('time(ms)')
    plt.ylabel('Amplitude(mV)')
    plt.grid(zorder = 1)
    plt.legend()
    plt.show()
    #return fit_plot
    
def parameter_plot(bunches, parameters, errors, parameter_names):
    for param_index, param_name in enumerate(parameter_names):
        if errors[param_index] is not None:
            plt.figure()
            plt.errorbar(bunches, parameters[param_index], errors[param_index], fmt='o', label=param_name)
            plt.xlabel('Kick')
            plt.ylabel(param_name)
            plt.title(f'Grafico di {param_name}')
            plt.legend()
            plt.grid(True)
            plt.show()
        else:
            plt.figure()
            plt.errorbar(bunches, parameters[param_index], fmt='o', label=param_name)
            plt.xlabel('Kick')
            plt.ylabel(param_name)
            plt.title(f'Grafico di {param_name}')
            plt.legend()
            plt.grid(True)
            plt.show()

def fft(plot, b):
    time = plot[0].get_xdata()
    signal = plot[0].get_ydata()
    step = time[2]-time[1]
    n    = len(time)
    yf   = rfft(signal)
    xf   = rfftfreq(n, step)
    plt.plot(xf, np.abs(yf))
    plt.grid(True)
    #plt.xscale('log')
    plt.xlim(0, 100)
    plt.title(f'Residual FFT bunch {b}')
    plt.xlabel('Frequency (kHz)')
    plt.ylabel('Magnitude')
    #print(xf[2]-xf[1])
    plt.show()
    '''yf_abs = np.abs(yf) 
    filt = yf_abs>82   # filter out those value under 300
    yf_filtered = filt * yf # noise frequency will be set to 0
    plt.plot(xf,np.abs(yf_filtered))
    plt.grid(True)
    #plt.xscale('log')
    plt.xlim(0, 25)
    plt.title(f'Residual FFT bunch {b}')
    plt.xlabel('Frequency (kHz)')
    plt.ylabel('Magnitude')
    plt.show()'''
   
    
    
    

            
            
      


# In[49]:


#leggo il Profile e definisco le variabili principali
filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')

filein_mean = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot_allkickinone.root")
filein_mean.cd()
g_trace_mean = filein_mean.Get('trace_kicks')

numBins = 1953
xMin = 0
xMax = 1


# In[109]:


'''profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)
x=np.array([])
y = np.array([])
y_err = np.array([])
profile = get_bunch(g_trace, profile, 0.03, 1.03) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
for i in range (profile.FindBin(0), profile.FindBin(1)):
    y_val = profile.GetBinContent(i)
    y_val_err = profile.GetBinError(i)
    t = profile.GetBinCenter(i)
    y = np.append(y, y_val)
    y_err = np.append(y_err, y_val_err)
    x = np.append(x, t)
fit_parameters = 11, 0.06, 0.4, 109.3, 3.3, 0
y_fit = ExpSin_Func(x, *fit_parameters)
plt.plot(x, y_fit, ls="--", label="truth")
plt.errorbar(x, y_fit, y_err, fmt="ok", label="data")
plt.xlim(0.3, 0.32)
plt.legend();
c = cost.LeastSquares(x, y, y_err, ExpSin_Func)
m1 = Minuit(c, A=11, tau=0.06, B=0.4, w=109.3, phi=3.3, C=0)
m1.visualize()
plt.plot(c.x, ExpSin_Func(c.x, *fit_parameters), ls="--", label="truth")
plt.xlim(0.3, 0.4)
m1.migrad()
m1.minos()'''


# In[110]:


'''profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)

A, tau, B, w, phi, C = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A, err_tau, err_B, err_w, err_phi, err_C = np.array([]), np.array([]), np.array([]),np.array([]), np.array([]), np.array([])
chi_squared, ndof, red_chi_squared = np.array([]), np.array([]), np.array([])
bunch = np.array([])

A_2, tau_2, B_2, w_2, phi_2, C_2 = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A_2, err_tau_2, err_B_2, err_w_2, err_phi_2, err_C_2 = np.array([]), np.array([]), np.array([]),np.array([]), np.array([]), np.array([])
chi_squared_2, ndof_2, red_chi_squared_2 = np.array([]), np.array([]), np.array([])

A_3, tau_3, B_3, w_3, phi_3, C_3 = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A_3, err_tau_3, err_B_3, err_w_3, err_phi_3, err_C_3 = np.array([]), np.array([]), np.array([]),np.array([]), np.array([]), np.array([])
chi_squared_3, ndof_3, red_chi_squared_3 = np.array([]), np.array([]), np.array([])

#y_subraction = np.array([])

chi_squared_sum = 0
chi_squared_sum_2 = 0
chi_squared_sum_3 = 0

for b in range(1,9):
    
    x=np.array([])
    y = np.array([])
    y_err = np.array([])
    y_subraction = np.array([])
    y_afterSub = np.array([])
    profile = get_bunch(g_trace, profile, 0.0+(b-1)*10, 1.0+(b-1)*10) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
    
    for i in range (profile.FindBin(0.03), profile.FindBin(1)):
        y_val = profile.GetBinContent(i)
        y_val_err = profile.GetBinError(i)
        t = profile.GetBinCenter(i)
        y = np.append(y, y_val)
        y_err = np.append(y_err, y_val_err)
        x = np.append(x, t)
        
    fit_parameters = 11, 0.06, 5, 24, 3.3, 0
    y_fit = ExpSin_Func(x, *fit_parameters)
    c = cost.LeastSquares(x, y, y_err, ExpSin_Func)
    m1 = Minuit(c, A=11, tau=0.06, B=5, w=24, phi=3.3, C=0)
    m1.migrad()
    m1.minos()
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1.valid)
    print("Parameter Values:", m1.values)
    print("Parameter Errors:", m1.errors)
    print("Chi-quadro:", m1.fval)
    print('ndof:', m1.ndof)
    print('Chi quadro ridotto:', m1.fval/m1.ndof)
    
    if m1.valid:
        A = np.append(A, m1.values['A'])
        tau = np.append(tau, m1.values['tau'])
        B = np.append(B, m1.values['B'])
        w = np.append(w, m1.values['w'])
        phi = np.append(phi, m1.values['phi'])
        C = np.append(C, m1.values['C'])
        
        err_A = np.append(err_A, m1.errors['A'])
        err_tau = np.append(err_tau, m1.errors['tau'])
        err_B = np.append(err_B, m1.errors['B'])
        err_w = np.append(err_w, m1.errors['w'])
        err_phi = np.append(err_phi, m1.errors['phi'])
        err_C = np.append(err_C, m1.errors['C'])
        
        chi_squared = np.append(chi_squared, m1.fval)
        ndof = np.append(ndof, m1.ndof)
        red_chi_squared = np.append(red_chi_squared, m1.fval/m1.ndof)
        chi_squared_sum += m1.fval
   
    bunch = np.append(bunch, b)
    optimized_params = [m1.values[param] for param in ['A', 'tau', 'B', 'w', 'phi', 'C']]
    y_fit_opt = ExpSin_Func(x, *optimized_params)
    Fit_Visualize(x, y, y_fit_opt, y_err, 0, 1, -9, 10, b)
    residual_plot = residual_graph(profile, ExpSin_Func, optimized_params, 0.03, 1, 0, 1, -10, 10, b)
    fft(residual_plot, b)
    
    #sottraggo frequenza 5 KHz
    y_subraction_2 = sin_func(x, B[b-1], w[b-1], phi[b-1]) 
    y_afterSub_2 = y - y_subraction_2
    plt.figure(figsize=(8, 6))
    plt.errorbar(x, y_afterSub_2, y_err, fmt="ok", label="data", markersize=3, capsize=0.2, zorder = 2)
    plt.xlim(0, 1)
    plt.ylim(-9, 10)
    plt.grid()
    plt.show()
    fit_parameters = 11, 0.06, 0.5, 18.2, 3, 0.0
    y_fit = ExpSin_Func(x, *fit_parameters)
    c = cost.LeastSquares(x, y_afterSub_2, y_err, ExpSin_Func)
    m1_2 = Minuit(c, A=11, tau=0.06, B=0.5, w=18.2, phi=3, C=0.0)
    #m1_2.fixed['C'] = True
    m1_2.migrad()
    #m1_2.minos()
    optimized_params_2 = [m1_2.values[param] for param in ['A', 'tau', 'B', 'w', 'phi', 'C']]
    y_fit_opt_2 = ExpSin_Func(x, *optimized_params_2)
    Fit_Visualize(x, y_afterSub_2, y_fit_opt_2, y_err, 0, 1, -9, 10, b)
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1_2.valid)
    print("Parameter Values:", m1_2.values)
    print("Parameter Errors:", m1_2.errors)
    print("Chi-quadro:", m1_2.fval)
    print('ndof:', m1_2.ndof)
    print('Chi quadro ridotto:', m1_2.fval/m1_2.ndof)
    
    #if m1_2.valid:
    A_2 = np.append(A_2, m1_2.values['A'])
    tau_2 = np.append(tau_2, m1_2.values['tau'])
    B_2 = np.append(B_2, m1_2.values['B'])
    w_2 = np.append(w_2, m1_2.values['w'])
    phi_2 = np.append(phi_2, m1_2.values['phi'])
    C_2 = np.append(C_2, m1_2.values['C'])
        
    err_A_2 = np.append(err_A_2, m1_2.errors['A'])
    err_tau_2 = np.append(err_tau_2, m1_2.errors['tau'])
    err_B_2 = np.append(err_B_2, m1_2.errors['B'])
    err_w_2 = np.append(err_w_2, m1_2.errors['w'])
    err_phi_2 = np.append(err_phi_2, m1_2.errors['phi'])
    err_C_2 = np.append(err_C_2, m1_2.errors['C'])
        
    chi_squared_2 = np.append(chi_squared_2, m1_2.fval)
    ndof_2 = np.append(ndof_2, m1_2.ndof)
    red_chi_squared_2 = np.append(red_chi_squared_2, m1_2.fval/m1_2.ndof)
    chi_squared_sum_2 += m1_2.fval
        
    #sottraggo frequenza 3.2 KHz
    y_subraction_3 = sin_func(x, B_2[b-1], w_2[b-1], phi_2[b-1]) 
    y_afterSub_3 = y_afterSub_2 - y_subraction_3
    plt.figure(figsize=(8, 6))
    plt.errorbar(x, y_afterSub_3, y_err, fmt="ok", label="data", markersize=3, capsize=0.2, zorder = 2)
    plt.xlim(0, 1)
    plt.ylim(-9, 10)
    plt.grid()
    plt.show()
    fit_parameters = 11, 0.06, 0.5, 107, 3, 0
    y_fit = ExpSin_Func(x, *fit_parameters)
    c = cost.LeastSquares(x, y_afterSub_3, y_err, ExpSin_Func)
    #m1_3 = Minuit(c, A=11, tau=0.06, C=0)
    m1_3 = Minuit(c, A=11, tau=0.06, B=0.5, w=107, phi=3, C=0)
    #m1_3.fixed['C'] = True
    m1_3.migrad()
    m1_3.minos()
    optimized_params_3 = [m1_3.values[param] for param in ['A', 'tau', 'B', 'w', 'phi', 'C']]
    y_fit_opt_3 = ExpSin_Func(x, *optimized_params_3)
    Fit_Visualize(x, y_afterSub_3, y_fit_opt_3, y_err, 0, 1, -9, 10, b)
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1_3.valid)
    print("Parameter Values:", m1_3.values)
    print("Parameter Errors:", m1_3.errors)
    print("Chi-quadro:", m1_3.fval)
    print('ndof:', m1_3.ndof)
    print('Chi quadro ridotto:', m1_3.fval/m1_3.ndof)
    
    if m1_3.valid:
        A_3 = np.append(A_3, m1_3.values['A'])
        tau_3 = np.append(tau_3, m1_3.values['tau'])
        B_3 = np.append(B_3, m1_3.values['B'])
        w_3 = np.append(w_3, m1_3.values['w'])
        phi_3 = np.append(phi_3, m1_3.values['phi'])
        C_3 = np.append(C_3, m1_3.values['C'])
        
        err_A_3 = np.append(err_A_3, m1_3.errors['A'])
        err_tau_3 = np.append(err_tau_3, m1_3.errors['tau'])
        err_B_3 = np.append(err_B_3, m1_3.errors['B'])
        err_w_3 = np.append(err_w_3, m1_3.errors['w'])
        err_phi_3 = np.append(err_phi_3, m1_3.errors['phi'])
        err_C_3 = np.append(err_C_3, m1_3.errors['C'])
        
        chi_squared_3 = np.append(chi_squared_3, m1_3.fval)
        ndof_3 = np.append(ndof_3, m1_3.ndof)
        red_chi_squared_3 = np.append(red_chi_squared_3, m1_3.fval/m1_3.ndof)
        chi_squared_sum_3 += m1_3.fval
         
parameters_3 = [A_3, tau_3, B_3, w_3, phi_3, C_3, chi_squared_3, ndof_3, red_chi_squared_3]  
parameters_names = ['A(mV)', 'tau(ms)', 'B(mV)', 'w(kHz)', 'phi', 'C(mV)', 'chi_squared', 'ndof', 'red_chi_squared']  
err_parameters_3 = [err_A_3, err_tau_3, err_B_3, err_w_3, err_phi_3, err_C_3, None, None, None]
parameter_plot(bunch, parameters_3, err_parameters_3, parameters_names)
print('somma dei chi quadro sugli 8 bunch:', chi_squared_sum_3)
#print("A:", np.mean(A), "tau:", np.mean(tau))'''


# In[50]:


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)

A, tau, B, w, phi, C, w2, phi2, D, w3, phi3, E = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A, err_tau, err_B, err_w, err_phi, err_C, err_w2, err_phi2, err_D, err_w3, err_phi3, err_E = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]),  np.array([]), np.array([]), np.array([])
chi_squared, ndof, red_chi_squared = np.array([]), np.array([]), np.array([])
bunch = np.array([])
chi_squared_sum = 0

for b in range(1,9):
    
    x=np.array([])
    y = np.array([])
    y_err = np.array([])
    
    profile = get_bunch(g_trace, profile, 0.0+(b-1)*10, 1.0+(b-1)*10) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
    
    for i in range (profile.FindBin(0.03), profile.FindBin(1)):
        y_val = profile.GetBinContent(i)
        y_val_err = profile.GetBinError(i)
        t = profile.GetBinCenter(i)
        y = np.append(y, y_val)
        y_err = np.append(y_err, y_val_err)
        x = np.append(x, t)
        
    fit_parameters = 11, 0.06, 0.4, 24, 3.3, 0.5, 12.2, 3, 0.5, 107, 3, 0
    y_fit = total_func(x, *fit_parameters)
    c = cost.LeastSquares(x, y, y_err, total_func)
    
    m1 = Minuit(c, A=11, tau=0.06, B=0.4, w=24, phi=3.0, C=0.5, w2=12.2, phi2=3, D=0.5, w3=107, phi3 = 3, E=0) 
    
    m1.fixed["w"] = True
    m1.values["w"] = 24.0
    m1.fixed["w2"] = True
    m1.values["w2"] = 14
    m1.fixed['w3'] = True
    m1.values['w3'] = 107
    #m1.fixed['phi'] = 3.0
    #m1.fixed['phi2'] = True
    #m1.fixed['phi2'] = 3

    
    m1.migrad()
    m1.minos()
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1.valid)
    print("Parameter Values:", m1.values)
    print("Parameter Errors:", m1.errors)
    print("Chi-quadro:", m1.fval)
    print('ndof:', m1.ndof)
    print('Chi quadro ridotto:', m1.fval/m1.ndof)
    
    if m1.valid:
        A = np.append(A, m1.values['A'])
        tau = np.append(tau, m1.values['tau'])
        B = np.append(B, m1.values['B'])
        w = np.append(w, m1.values['w'])
        phi = np.append(phi, m1.values['phi'])
        C = np.append(C, m1.values['C'])
        w2 = np.append(w2, m1.values['w2'])
        phi2 = np.append(phi2, m1.values['phi2'])
        D = np.append(D, m1.values['D'])
        w3 = np.append(w3, m1.values['w3'])
        phi3 = np.append(phi3, m1.values['phi3'])
        E = np.append(E, m1.values['E'])

        err_A = np.append(err_A, m1.errors['A'])
        err_tau = np.append(err_tau, m1.errors['tau'])
        err_B = np.append(err_B, m1.errors['B'])
        err_w = np.append(err_w, m1.errors['w'])
        err_phi = np.append(err_phi, m1.errors['phi'])
        err_C = np.append(err_C, m1.errors['C'])
        err_w2 = np.append(err_w2, m1.errors['w2'])
        err_phi2 = np.append(err_phi2, m1.errors['phi2'])
        err_D = np.append(err_D, m1.errors['D'])
        err_w3 = np.append(err_w3, m1.errors['w3'])
        err_phi3 = np.append(err_phi3, m1.errors['phi3'])
        err_E = np.append(err_E, m1.errors['E'])

        
        chi_squared = np.append(chi_squared, m1.fval)
        ndof = np.append(ndof, m1.ndof)
        red_chi_squared = np.append(red_chi_squared, m1.fval/m1.ndof)
        chi_squared_sum += m1.fval
    
    bunch = np.append(bunch, b)
    optimized_params = [m1.values[param] for param in ['A', 'tau', 'B', 'w', 'phi', 'C', 'w2', 'phi2', 'D', 'w3', 'phi3', 'E']]
    y_fit_opt = total_func(x, *optimized_params)
    Fit_Visualize(x, y, y_fit_opt, y_err, 0, 1.0, -9, 10, b)
    residual_plot = residual_graph(profile, total_func, optimized_params, 0.03, 1, 0, 1, -10, 10, b)
    fft(residual_plot, b)
    
parameters = [A, tau, B, w, phi, C, w2, phi2, D, w3, phi3, E, chi_squared, ndof, red_chi_squared]
#parameters_2 = [E, chi_squared, ndof, red_chi_squared]
parameters_names = ['A(mV)', 'tau(ms)', 'B(mV)', 'w(kHz)', 'phi', 'C(mV)', 'w2(kHz)', 'phi2', 'D(mV)', 'w3(kHz)', 'phi3', 'E','chi_squared', 'ndof', 'red_chi_squared']  
#parameters_names_2 = ['E','chi_squared', 'ndof', 'red_chi_squared']
err_parameters = [err_A, err_tau, err_B, err_w, err_phi, err_C, err_w2, err_phi2, err_D, err_w3, err_phi3, err_E, None, None, None]
#err_parameters_2 = [err_E, None, None, None]
parameter_plot(bunch, parameters, err_parameters, parameters_names)
#parameter_plot(bunch, parameters_2, err_parameters_2, parameters_names_2)
print('somma dei chi quadro sugli 8 bunch:', chi_squared_sum)

#print("A:", np.mean(A), "tau:", np.mean(tau))


# In[39]:


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)

A, tau, B, w, phi, C = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A, err_tau, err_B, err_w, err_phi, err_C = np.array([]), np.array([]), np.array([]),np.array([]), np.array([]), np.array([])
chi_squared, ndof, red_chi_squared = np.array([]), np.array([]), np.array([])
bunch = np.array([])

chi_squared_sum = 0

for b in range(1,9):
    
    x=np.array([])
    y = np.array([])
    y_err = np.array([])
    y_subraction = np.array([])
    y_afterSub = np.array([])
    profile = get_bunch(g_trace, profile, 0.0+(b-1)*10, 1.0+(b-1)*10) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
    
    for i in range (profile.FindBin(0.03), profile.FindBin(1)):
        y_val = profile.GetBinContent(i)
        y_val_err = profile.GetBinError(i)
        t = profile.GetBinCenter(i)
        y = np.append(y, y_val)
        y_err = np.append(y_err, y_val_err)
        x = np.append(x, t)
        
    fit_parameters = 11, 0.06, 0
    y_fit = exp_func(x, *fit_parameters)
    c = cost.LeastSquares(x, y, y_err, exp_func)
    m1 = Minuit(c, A=11, tau=0.06, C=0)
    m1.migrad()
    m1.minos()
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1.valid)
    print("Parameter Values:", m1.values)
    print("Parameter Errors:", m1.errors)
    print("Chi-quadro:", m1.fval)
    print('ndof:', m1.ndof)
    print('Chi quadro ridotto:', m1.fval/m1.ndof)
    
    if m1.valid:
        A = np.append(A, m1.values['A'])
        tau = np.append(tau, m1.values['tau'])
        C = np.append(C, m1.values['C'])
        
        err_A = np.append(err_A, m1.errors['A'])
        err_tau = np.append(err_tau, m1.errors['tau'])
        err_C = np.append(err_C, m1.errors['C'])
        
        chi_squared = np.append(chi_squared, m1.fval)
        ndof = np.append(ndof, m1.ndof)
        red_chi_squared = np.append(red_chi_squared, m1.fval/m1.ndof)
        chi_squared_sum += m1.fval
   
    bunch = np.append(bunch, b)
    optimized_params = [m1.values[param] for param in ['A', 'tau', 'C']]
    y_fit_opt = exp_func(x, *optimized_params)
    Fit_Visualize(x, y, y_fit_opt, y_err, 0, 1, -9, 10, b)
    residual_plot = residual_graph(profile, exp_func, optimized_params, 0.03, 1, 0, 1, -10, 10, b)
    fft(residual_plot, b)
         
parameters = [A, tau, C, chi_squared, ndof, red_chi_squared]  
parameters_names = ['A(mV)', 'tau(ms)', 'C(mV)', 'chi_squared', 'ndof', 'red_chi_squared']  
err_parameters = [err_A, err_tau, err_C, None, None, None]
parameter_plot(bunch, parameters, err_parameters, parameters_names)
print('somma dei chi quadro sugli 8 bunch:', chi_squared_sum)
#print("A:", np.mean(A), "tau:", np.mean(tau))


# In[22]:


'''profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)

A, tau, B, w, phi, C, w2, phi2, D, w3, phi3, E, w4, phi4, F, w5, phi5, G= np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A, err_tau, err_B, err_w, err_phi, err_C, err_w2, err_phi2, err_D, err_w3, err_phi3, err_E, err_w4, err_phi4, err_F, err_w5, err_phi5, err_G  = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]),  np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]) 
chi_squared, ndof, red_chi_squared = np.array([]), np.array([]), np.array([])
bunch = np.array([])
chi_squared_sum = 0

for b in range(1,9):
    
    x=np.array([])
    y = np.array([])
    y_err = np.array([])
    
    profile = get_bunch(g_trace, profile, 0.0+(b-1)*10, 1.0+(b-1)*10) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
    
    for i in range (profile.FindBin(0.03), profile.FindBin(1)):
        y_val = profile.GetBinContent(i)
        y_val_err = profile.GetBinError(i)
        t = profile.GetBinCenter(i)
        y = np.append(y, y_val)
        y_err = np.append(y_err, y_val_err)
        x = np.append(x, t)
        
    fit_parameters = 11, 0.06, 0.4, 24, 3.3, 0.5, 12.2, 3, 0.5, 107, 3, 0.3, 270, 3, 0.3, 630, 3, 0 
    y_fit = total_func(x, *fit_parameters)
    c = cost.LeastSquares(x, y, y_err, total_func)
    
    m1 = Minuit(c, A=11, tau=0.06, B=0.4, w=24, phi=3.0, C=0.5, w2=12.2, phi2=3, D=0.5, w3=107, phi3 = 3, E=0.3, w4=270, phi4 = 3, F = 0.3, w5=630, phi5 = 3, G=0)
    
    m1.fixed["w"] = True
    m1.values["w"] = 24.0
    m1.fixed["w2"] = True
    m1.values["w2"] = 14
    m1.fixed['w3'] = True
    m1.values['w3'] = 107
    m1.fixed['w4'] = True
    m1.values['w4'] = 270
    m1.fixed['w5'] = True
    m1.values['w5'] = 630
    
    #m1.fixed['phi'] = 3.0
    #m1.fixed['phi2'] = True
    #m1.fixed['phi2'] = 3

    
    m1.migrad()
    m1.minos()
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1.valid)
    print("Parameter Values:", m1.values)
    print("Parameter Errors:", m1.errors)
    print("Chi-quadro:", m1.fval)
    print('ndof:', m1.ndof)
    print('Chi quadro ridotto:', m1.fval/m1.ndof)
    
    if m1.valid:
        A = np.append(A, m1.values['A'])
        tau = np.append(tau, m1.values['tau'])
        B = np.append(B, m1.values['B'])
        w = np.append(w, m1.values['w'])
        phi = np.append(phi, m1.values['phi'])
        C = np.append(C, m1.values['C'])
        w2 = np.append(w2, m1.values['w2'])
        phi2 = np.append(phi2, m1.values['phi2'])
        D = np.append(D, m1.values['D'])
        w3 = np.append(w3, m1.values['w3'])
        phi3 = np.append(phi3, m1.values['phi3'])
        E = np.append(E, m1.values['E'])
        w4 = np.append(w4, m1.values['w4'])
        phi4 = np.append(phi4, m1.values['phi4'])
        F = np.append(F, m1.values['F'])
        w5 = np.append(w5, m1.values['w5'])
        phi5 = np.append(phi5, m1.values['phi5'])
        G = np.append(G, m1.values['G'])

        err_A = np.append(err_A, m1.errors['A'])
        err_tau = np.append(err_tau, m1.errors['tau'])
        err_B = np.append(err_B, m1.errors['B'])
        err_w = np.append(err_w, m1.errors['w'])
        err_phi = np.append(err_phi, m1.errors['phi'])
        err_C = np.append(err_C, m1.errors['C'])
        err_w2 = np.append(err_w2, m1.errors['w2'])
        err_phi2 = np.append(err_phi2, m1.errors['phi2'])
        err_D = np.append(err_D, m1.errors['D'])
        err_w3 = np.append(err_w3, m1.errors['w3'])
        err_phi3 = np.append(err_phi3, m1.errors['phi3'])
        err_E = np.append(err_E, m1.errors['E'])
        err_w4 = np.append(err_w4, m1.values['w4'])
        err_phi4 = np.append(err_phi4, m1.values['phi4'])
        err_F = np.append(err_F, m1.values['F'])
        err_w5 = np.append(err_w5, m1.values['w5'])
        err_phi5 = np.append(err_phi5, m1.values['phi5'])
        err_G = np.append(err_G, m1.values['G'])


        
        chi_squared = np.append(chi_squared, m1.fval)
        ndof = np.append(ndof, m1.ndof)
        red_chi_squared = np.append(red_chi_squared, m1.fval/m1.ndof)
        chi_squared_sum += m1.fval
    
    bunch = np.append(bunch, b)
    optimized_params = [m1.values[param] for param in ['A', 'tau', 'B', 'w', 'phi', 'C', 'w2', 'phi2', 'D', 'w3', 'phi3', 'E', 'w4', 'phi4', 'F', 'w5', 'phi5', 'G']]
    y_fit_opt = total_func(x, *optimized_params)
    Fit_Visualize(x, y, y_fit_opt, y_err, 0, 0.2, -9, 10, b)
    residual_plot = residual_graph(profile, total_func, optimized_params, 0.03, 1, 0, 1, -10, 10, b)
    fft(residual_plot, b)
    
parameters = [A, tau, B, w, phi, C, w2, phi2, D, w3, phi3, E, w4, phi4, F, w5, phi5, G, chi_squared, ndof, red_chi_squared]
#parameters_2 = [E, chi_squared, ndof, red_chi_squared]
parameters_names = ['A(mV)', 'tau(ms)', 'B(mV)', 'w(kHz)', 'phi', 'C(mV)', 'w2(kHz)', 'phi2', 'D(mV)', 'w3(kHz)', 'phi3', 'E','chi_squared', 'ndof', 'red_chi_squared']  
#parameters_names_2 = ['E','chi_squared', 'ndof', 'red_chi_squared']
err_parameters = [err_A, err_tau, err_B, err_w, err_phi, err_C, err_w2, err_phi2, err_D,
                  err_w3, err_phi3, err_E, err_w4, err_phi4, err_F, err_w5, err_phi5, G, None, None, None]
#err_parameters_2 = [err_E, None, None, None]
parameter_plot(bunch, parameters, err_parameters, parameters_names)
#parameter_plot(bunch, parameters_2, err_parameters_2, parameters_names_2)
print('somma dei chi quadro sugli 8 bunch:', chi_squared_sum)

#print("A:", np.mean(A), "tau:", np.mean(tau))'''


# In[51]:


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot_allkickinone.root")
filein.cd()
g_trace = filein.Get('trace_kicks')

profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)

'''A_mean, tau_mean, B_mean, w_mean, phi_mean, C_mean, w2_mean, phi2_mean, D_mean, w3_mean, phi3_mean, E_mean = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
err_A_mean, err_tau_mean, err_B_mean, err_w_mean, err_phi_mean, err_C_mean, err_w2_mean, err_phi2_mean, err_D_mean, err_w3_mean, err_phi3_mean, err_E_mean = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
chi_squared_mean, ndof_mean, red_chi_squared_mean = 0, 0, 0'''
    
x=np.array([])
y = np.array([])
y_err = np.array([])
    
profile = get_bunch(g_trace, profile, 0.0, 1.0) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
    
for i in range (profile.FindBin(0.03), profile.FindBin(1)):
        y_val = profile.GetBinContent(i)
        y_val_err = profile.GetBinError(i)
        t = profile.GetBinCenter(i)
        y = np.append(y, y_val)
        y_err = np.append(y_err, y_val_err)
        x = np.append(x, t)
        
fit_parameters = 11, 0.06, 0.4, 24, 3.3, 0.5, 12.2, 3, 0.5, 107, 3, 0
y_fit = total_func(x, *fit_parameters)
c = cost.LeastSquares(x, y, y_err, total_func)
    
m1 = Minuit(c, A=11, tau=0.06, B=0.4, w=24, phi=3.0, C=0.5, w2=12.2, phi2=3, D=0.5, w3=107, phi3 = 3, E=0) 
    
m1.fixed["w"] = True
m1.values["w"] = 24.0
m1.fixed["w2"] = True
m1.values["w2"] = 14
m1.fixed['w3'] = True
m1.values['w3'] = 107

#m1.fixed['phi'] = 3.0
#m1.fixed['phi2'] = True
#m1.fixed['phi2'] = 3

    
m1.migrad()
m1.minos()
    
print(f"Intervallo {(b - 1) + 1}:")
print("Validità:", m1.valid)
print("Parameter Values:", m1.values)
print("Parameter Errors:", m1.errors)
print("Chi-quadro:", m1.fval)
print('ndof:', m1.ndof)
print('Chi quadro ridotto:', m1.fval/m1.ndof)
    
if m1.valid:
        A = np.append(A, m1.values['A'])
        tau = np.append(tau, m1.values['tau'])
        B = np.append(B, m1.values['B'])
        w = np.append(w, m1.values['w'])
        phi = np.append(phi, m1.values['phi'])
        C = np.append(C, m1.values['C'])
        w2 = np.append(w2, m1.values['w2'])
        phi2 = np.append(phi2, m1.values['phi2'])
        D = np.append(D, m1.values['D'])
        w3 = np.append(w3, m1.values['w3'])
        phi3 = np.append(phi3, m1.values['phi3'])
        E = np.append(E, m1.values['E'])

        err_A = np.append(err_A, m1.errors['A'])
        err_tau = np.append(err_tau, m1.errors['tau'])
        err_B = np.append(err_B, m1.errors['B'])
        err_w = np.append(err_w, m1.errors['w'])
        err_phi = np.append(err_phi, m1.errors['phi'])
        err_C = np.append(err_C, m1.errors['C'])
        err_w2 = np.append(err_w2, m1.errors['w2'])
        err_phi2 = np.append(err_phi2, m1.errors['phi2'])
        err_D = np.append(err_D, m1.errors['D'])
        err_w3 = np.append(err_w3, m1.errors['w3'])
        err_phi3 = np.append(err_phi3, m1.errors['phi3'])
        err_E = np.append(err_E, m1.errors['E'])

        
        chi_squared = np.append(chi_squared, m1.fval)
        ndof = np.append(ndof, m1.ndof)
        red_chi_squared = np.append(red_chi_squared, m1.fval/m1.ndof)

    
bunch = 'media'
optimized_params = [m1.values[param] for param in ['A', 'tau', 'B', 'w', 'phi', 'C', 'w2', 'phi2', 'D', 'w3', 'phi3', 'E']]
y_fit_opt = total_func(x, *optimized_params)
Fit_Visualize(x, y, y_fit_opt, y_err, 0, 1, -9, 10, bunch)
residual_plot = residual_graph(profile, total_func, optimized_params, 0.03, 1, 0, 1, -10, 10, b)
fft(residual_plot, b)
    
'''parameters_mean = [A_mean, tau_mean, B_mean, w_mean, phi_mean, C_mean, w2_mean, phi2_mean, D_mean, w3_mean, phi3_mean, E_mean, chi_squared_mean, ndof_mean, red_chi_squared_mean]
#parameters_2 = [E, chi_squared, ndof, red_chi_squared]
parameters_names = ['A(mV)', 'tau(ms)', 'B(mV)', 'w(kHz)', 'phi', 'C(mV)', 'w2(kHz)', 'phi2', 'D(mV)', 'w3(kHz)', 'phi3', 'E','chi_squared', 'ndof', 'red_chi_squared']  
#parameters_names_2 = ['E','chi_squared', 'ndof', 'red_chi_squared']
err_parameters_mean = [err_A_mean, err_tau_mean, err_B_mean, err_w_mean, err_phi_mean, err_C_mean, err_w2_mean, err_phi2_mean, err_D_mean, err_w3_mean, err_phi3_mean, err_E_mean, None, None, None]
#err_parameters_2 = [err_E, None, None, None]
parameter_plot('media', parameters_mean, err_parameters_mean, parameters_names)
#parameter_plot(bunch, parameters_2, err_parameters_2, parameters_names_2)
print('somma dei chi quadro sugli 8 bunch:', chi_squared_sum)

#print("A:", np.mean(A), "tau:", np.mean(tau))'''


# In[52]:


kicks = [1, 2, 3, 4, 5, 6, 7, 8, 9]
plt.errorbar(kicks, A, yerr=err_A, fmt='o')
#plt.axhspan(A[8] - err_A[8], A[8] + err_A[8], facecolor='violet',
            #alpha=0.5, xmin=0, xmax=1, label='Sfondo')
plt.ylim()
plt.xlabel('Kick')
plt.ylabel('A param')
plt.title('A Plot')
plt.legend()
plt.grid(True)
plt.show()

plt.errorbar(kicks, tau, yerr=err_tau, fmt='o')
#plt.axhspan(tau[8] - err_tau[8], tau[8] + err_tau[8], facecolor='violet',
            #alpha=0.5, xmin=0, xmax=1, label='Sfondo')
plt.ylim()
plt.xlabel('Kick')
plt.ylabel('tau param')
plt.title('tau Plot')
plt.legend()
plt.grid(True)
plt.show()

plt.errorbar(kicks, ndof, fmt='o')
#plt.axhspan(tau[8] - err_tau[8], tau[8] + err_tau[8], facecolor='violet',
            #alpha=0.5, xmin=0, xmax=1, label='Sfondo')
plt.ylim()
plt.xlabel('Kick')
plt.ylabel('ndof')
plt.title('ndof Plot')
plt.legend()
plt.grid(True)
plt.show()

print(A[8])
print(err_A[8])
print(tau[8])
print(err_tau[8])


# In[32]:


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)
graph_res = ROOT.TGraphErrors()
hist_res = ROOT.TH1F("residual", "Residui", numBins, xMin, xMax)

A, tau, B, tau2, w, phi, C, w2, phi2, D, w3, phi3, E = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
err_A, err_tau, err_B, err_tau2, err_w, err_phi, err_C, err_w2, err_phi2, err_D, err_w3, err_phi3, err_E = np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]),  np.array([]), np.array([]), np.array([]), np.array([])
chi_squared, ndof, red_chi_squared = np.array([]), np.array([]), np.array([])
bunch = np.array([])
chi_squared_sum = 0

for b in range(1,9):
    
    x=np.array([])
    y = np.array([])
    y_err = np.array([])
    
    profile = get_bunch(g_trace, profile, 0.0+(b-1)*10, 1.0+(b-1)*10) #qui devo inserire tmin e tmax in cui voglio fare il fit di g_trace
    
    for i in range (profile.FindBin(0.03), profile.FindBin(1)):
        y_val = profile.GetBinContent(i)
        y_val_err = profile.GetBinError(i)
        t = profile.GetBinCenter(i)
        y = np.append(y, y_val)
        y_err = np.append(y_err, y_val_err)
        x = np.append(x, t)
        
    fit_parameters = 11, 0.06, 0.4, 1.0, 24, 3.3, 0.5, 12.2, 3, 0.5, 107, 3, 0
    y_fit = ExpSinDecay_Func(x, *fit_parameters)
    c = cost.LeastSquares(x, y, y_err, ExpSinDecay_Func)
    
    m1 = Minuit(c, A=11, tau=0.06, B=0.4, tau2=1.0, w=24, phi=3.0, C=0.5, w2=12.2, phi2=3, D=0.5, w3=107, phi3 = 3, E=0) 
    
    m1.fixed["w"] = True
    m1.values["w"] = 24.0
    m1.fixed["w2"] = True
    m1.values["w2"] = 14
    m1.fixed['w3'] = True
    m1.values['w3'] = 107
    m1.fixed['tau2'] = True
    m1.values['tau2'] = 1.0
    #m1.fixed['phi'] = 3.0
    #m1.fixed['phi2'] = True
    #m1.fixed['phi2'] = 3

    
    m1.migrad()
    m1.minos()
    
    print(f"Intervallo {(b - 1) + 1}:")
    print("Validità:", m1.valid)
    print("Parameter Values:", m1.values)
    print("Parameter Errors:", m1.errors)
    print("Chi-quadro:", m1.fval)
    print('ndof:', m1.ndof)
    print('Chi quadro ridotto:', m1.fval/m1.ndof)
    
    if m1.valid:
        A = np.append(A, m1.values['A'])
        tau = np.append(tau, m1.values['tau'])
        B = np.append(B, m1.values['B'])
        tau2 = np.append(tau2, m1.values['tau2'])
        w = np.append(w, m1.values['w'])
        phi = np.append(phi, m1.values['phi'])
        C = np.append(C, m1.values['C'])
        w2 = np.append(w2, m1.values['w2'])
        phi2 = np.append(phi2, m1.values['phi2'])
        D = np.append(D, m1.values['D'])
        w3 = np.append(w3, m1.values['w3'])
        phi3 = np.append(phi3, m1.values['phi3'])
        E = np.append(E, m1.values['E'])

        err_A = np.append(err_A, m1.errors['A'])
        err_tau = np.append(err_tau, m1.errors['tau'])
        err_B = np.append(err_B, m1.errors['B'])
        err_tau2 = np.append(err_tau2, m1.errors['tau2'])
        err_w = np.append(err_w, m1.errors['w'])
        err_phi = np.append(err_phi, m1.errors['phi'])
        err_C = np.append(err_C, m1.errors['C'])
        err_w2 = np.append(err_w2, m1.errors['w2'])
        err_phi2 = np.append(err_phi2, m1.errors['phi2'])
        err_D = np.append(err_D, m1.errors['D'])
        err_w3 = np.append(err_w3, m1.errors['w3'])
        err_phi3 = np.append(err_phi3, m1.errors['phi3'])
        err_E = np.append(err_E, m1.errors['E'])

        
        chi_squared = np.append(chi_squared, m1.fval)
        ndof = np.append(ndof, m1.ndof)
        red_chi_squared = np.append(red_chi_squared, m1.fval/m1.ndof)
        chi_squared_sum += m1.fval
    
    bunch = np.append(bunch, b)
    optimized_params = [m1.values[param] for param in ['A', 'tau', 'B', 'tau2', 'w', 'phi', 'C', 'w2', 'phi2', 'D', 'w3', 'phi3', 'E']]
    y_fit_opt = ExpSinDecay_Func(x, *optimized_params)
    Fit_Visualize(x, y, y_fit_opt, y_err, 0, 1.0, -9, 10, b)
    residual_plot = residual_graph(profile, ExpSinDecay_Func, optimized_params, 0.03, 1, 0, 1, -10, 10, b)
    fft(residual_plot, b)
    
parameters = [A, tau, B, tau2, w, phi, C, w2, phi2, D, w3, phi3, E, chi_squared, ndof, red_chi_squared]
#parameters_2 = [E, chi_squared, ndof, red_chi_squared]
parameters_names = ['A(mV)', 'tau(ms)', 'B(mV)', 'tau2', 'w(kHz)', 'phi', 'C(mV)', 'w2(kHz)', 'phi2', 'D(mV)', 'w3(kHz)', 'phi3', 'E','chi_squared', 'ndof', 'red_chi_squared']  
#parameters_names_2 = ['E','chi_squared', 'ndof', 'red_chi_squared']
err_parameters = [err_A, err_tau, err_B, err_tau2, err_w, err_phi, err_C, err_w2, err_phi2, err_D, err_w3, err_phi3, err_E, None, None, None]
#err_parameters_2 = [err_E, None, None, None]
parameter_plot(bunch, parameters, err_parameters, parameters_names)
#parameter_plot(bunch, parameters_2, err_parameters_2, parameters_names_2)
print('somma dei chi quadro sugli 8 bunch:', chi_squared_sum)

#print("A:", np.mean(A), "tau:", np.mean(tau))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




