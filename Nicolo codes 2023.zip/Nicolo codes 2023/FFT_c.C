%%cpp

#include "TVirtualFFT.h"
#include "TFile.h"
#include "TH1.h"

TH1F* SetupFFT(TH1D* h, double xmin, double xmax) {
    double timeTot = xmax - xmin;
    double binW = h->GetBinWidth(1);
    int nBins = timeTot / binW;
    TH1F* hout = new TH1F("", "", nBins, xmin, xmin + (nBins * binW));

    int binCount = 0;
    for (int i = 0; i < h->GetXaxis()->GetNbins(); i++) {
        if (h->GetBinCenter(i) < xmin) continue;
        if (binCount > nBins) break;
        binCount++;
        double cont = h->GetBinContent(i);
        double err = h->GetBinError(i);
        hout->SetBinContent(binCount, cont);
        hout->SetBinError(binCount, err);
    }
    return hout;
}



TH1F* RescaleAxis(TH1* input, Double_t Scale) {
    int bins = input->GetNbinsX();
    TAxis* xaxis = input->GetXaxis();
    double* ba = new double[bins + 1];
    xaxis->GetLowEdge(ba);
    ba[bins] = ba[bins - 1] + xaxis->GetBinWidth(bins);
    for (int i = 0; i < bins + 1; i++) {
        ba[i] *= Scale;
    }
    TH1F* out = new TH1F("out_rescaled", input->GetTitle(), bins, ba);
    for (int i = 0; i <= bins; i++) {
        out->SetBinContent(i, input->GetBinContent(i));
        out->SetBinError(i, input->GetBinError(i));
    }
    return out;
}


void FFT_HOWTO_Anna() {
    /*TH1F* residual = new TH1F("residual", "", 100, 0, 100);
    residual->FillRandom("pol0", 1e5);
    for (int i = 1; i <= residual->GetXaxis()->GetNbins(); i++) {
        residual->SetBinContent(i, residual->GetBinContent(i) - 1000);
    }
    residual->SaveAs("/home/nicolo/FD_R0_analyses/test/analysis_eddy/res_try.root");*/

    TFile* filein = new TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_2Kick_exp+sin.root", "READ");
    filein->cd();
    TH1D* g_trace = (TH1D*)filein->Get("residual");

    TH1* fft_histogram = 0;
    TVirtualFFT::SetTransform(0);

    TH1F* fftResidualInit = SetupFFT(g_trace, 0.03, 1);
    fft_histogram = fftResidualInit->FFT(fft_histogram, "MAG");
    TH1F* fftResidual = RescaleAxis(fft_histogram, 1.0 / (1 - 0.03));
    fftResidual->SetTitle(";Frequency (MHz);Magnitude [Arb Units]");
    fftResidual->SetStats(0);
    fftResidual->SetName("residualFFT");
    fftResidual->Scale(1.0 / fftResidual->Integral());
    fftResidual->GetXaxis()->SetRangeUser(0, fftResidual->GetXaxis()->GetXmax() / 2.0);
    TCanvas* c1 = new TCanvas("c1", "Log X Axis Plot", 800, 600);
    //c1->SetLogx();
    fftResidual->Draw("HIST");
    c1->SaveAs("/home/nicolo/FD_R0_analyses/test/analysis_eddy/FFT_residual_2kick_exp+sin.root");
}
    //fftResidual->SaveAs("/home/nicolo/FD_R0_analyses/test/analysis_eddy/FFT_try.root");

FFT_HOWTO_Anna();



