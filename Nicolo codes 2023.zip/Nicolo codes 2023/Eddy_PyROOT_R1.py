#!/usr/bin/env python
# coding: utf-8

# In[1]:


import ROOT
import numpy as np
import pandas as pd
import os


# In[2]:


import os
import ROOT

def plot_1(folder="/home/nicolo/FD_R0_analyses/EddyCurrents/SD_R1/SD_R1_for1mean",
           output_folder="/home/nicolo/FD_R0_analyses/test/analysis_eddy"):

    SaveFigs = True
    
    Npoints = 204400
    tstart = -0.2
    tend = 104.4528
    dt = (tend - tstart) / Npoints
    #dt=0.000512
    c=[0.44924800725720093, 1.5315427682288465, -0.015387108715039649, -0.24407205059385786, -0.6861436070837124,
           -0.6400115983755049, -1.1532537968331094, -1.4067210270901183]
    
    

    
    h2_trace = ROOT.TH2F("h2_trace", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)
    h2_trace_kicks = ROOT.TH2F("h2_trace_kicks", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)
    #h2_max = ROOT.TH2F("h2_trace_max", "max trace", Npoints, tstart, tend, 5000, -100, 1000000)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        #trace_2 = []
        new_trace = []
        new_trace_2 = []
        time_of_max = []
        
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0
        j=0

        with open(file_path, 'r') as file:
    
            for _ in range(3):
                file.readline()
                

            for line in file:
                
                
                time, A, B, C_str, D, avgC_str = line.split(',')
                time = float(time)
                A = float(A)
                B = float(B)
                if C_str.strip() == '∞':
                    C = float(999.0)
                else:
                    C = float(C_str)    
                D = float(D)
                if avgC_str.strip() == '∞':
                    avgC = float(999.0)
                else:
                    avgC = float(avgC_str)
                    
                    
                avgC = avgC * 1000
                trace.append((time, avgC))
                
                '''for i, (time, avgC) in enumerate(trace):
                    if avgC == 0:
                        if i > 0 and i < len(trace) - 1:
                            previous_avgC = trace[i - 1][1]
                            next_avgC = trace[i + 1][1]
                            avgC = (previous_avgC + next_avgC) / 2
                    trace_2.append((time, avgC))'''
                    
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if avgC > 990000:
                    if time > j*10 + 1 and time < (j+1)*10 + 1:
                        time_of_max.append(time)
                        j+=1
                        '''print(time)
                        print(avgC)'''
                if time < 5:
                    offset += avgC
                    off += 1
                

        offset = offset / (1.0 * off)
        #h2_max.Fill(max_time, max_amplitude)
        
        for time, avgC in trace:
        #for time, avgC in trace_2:
            if avgC == 0:
                print('trovato')
                avgC = (avgC[-1][1]+avgC[1][1])/2
            #new_time = time-max_time
            new_time = time
            new_avgC = avgC-offset
            #new_trace.append((new_time, avgC))
            new_trace.append(new_time)
            new_trace_2.append(new_avgC)
            h2_trace.Fill(time - max_time, (avgC - offset))
        for i in range (1, 9):
            this_guess = i*10
            for j in range(len(new_trace)):
                if new_trace[j] > this_guess:
                    prev_time = new_trace[j-1]
                    prev_avgC = new_trace_2[j-1]
                    if prev_avgC > 200:
                        if new_trace_2[j] < 200:
                            fraction = (200 - prev_avgC)/(new_trace_2[j]-prev_avgC)
                            kick_time = prev_time + dt*fraction
                            #kick_time = max_time
                            for k in range(len(new_trace)):
                                t_time = new_trace[k]
                                t_avgC = new_trace_2[k] #- c[i-1]
                                if t_time >= kick_time - 0.5 and t_time < kick_time + 3:
                                    h2_trace_kicks.Fill(t_time-time_of_max[i-1], t_avgC)
                                        #print(t_avgC)
                                        
                                        #print(c[i-1])
        #print(len(new_trace))
        fi += 1
        

    c_h2_trace_kicks = ROOT.TCanvas()
    #h2_trace_kicks.GetYaxis().SetRangeUser(-160, 900)
    h2_trace_kicks.GetXaxis().SetRangeUser(0, 1.0)
    h2_trace_kicks.GetYaxis().SetRangeUser(-100.0, 100.0)
    h2_trace_kicks.Draw("colz")
    if SaveFigs:
        c_h2_trace_kicks.SaveAs(os.path.join(output_folder, "eddy_for1mean_kicks.png"))


    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    #h2_trace.GetXaxis().SetRangeUser(0.02, 0.025)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "eddy_for1mean.png"))
        
    '''c_h2_trace_max = ROOT.TCanvas()
    #h2_max.GetYaxis().SetRangeUser()
    #h2_max.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "eddy_for1mean_max.png"))'''

        
    fout = ROOT.TFile(os.path.join(output_folder, "eddy_for1mean.root"), "recreate")
    h2_trace.Write()
    h2_trace_kicks.Write()
    #h2_max.Write()
    fout.Close()
    

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_1()

#dopo che trovi i tempi che corrispondono all'infinito li devi sottrarre attraverso un vettore quando riempi il nuovo istogramma


# In[3]:


import os
import ROOT

def plot_1(folder="/home/nicolo/FD_R0_analyses/EddyCurrents/SD_R1/SD_R1_for2mean",
           output_folder="/home/nicolo/FD_R0_analyses/test/analysis_eddy"):

    SaveFigs = True
    
    Npoints = 204400
    tstart = -0.2
    tend = 104.4528
    dt = (tend - tstart) / Npoints
    #dt=0.000512
    c=[0.44924800725720093, 1.5315427682288465, -0.015387108715039649, -0.24407205059385786, -0.6861436070837124,
           -0.6400115983755049, -1.1532537968331094, -1.4067210270901183]
    
    
    h2_trace = ROOT.TH2F("h2_trace", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)
    h2_trace_kicks = ROOT.TH2F("h2_trace_kicks", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        new_trace = []
        new_trace_2 = []
        time_of_max = []
        
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                
                
                time, A, B, C_str, D, avgC_str = line.split(',')
                time = float(time)
                A = float(A)
                B = float(B)
                if C_str.strip() == '∞':
                    C = float(999.0)
                else:
                    C = float(C_str)    
                D = float(D)
                if avgC_str.strip() == '∞':
                    avgC = float(999.0)
                else:
                    avgC = float(avgC_str)
                    
                    
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if avgC > 990000:
                    if time > j*10 + 1 and time < (j+1)*10 + 1:
                        time_of_max.append(time)
                        j+=1
                        '''print(time)
                        print(avgC)'''
                if time < 5:
                    offset += avgC
                    off += 1
                    j=0
                

        offset = offset / (1.0 * off)
        #h2_max.Fill(max_time, max_amplitude)
        
        for time, avgC in trace:
            if avgC == 0:
                avgC = (avgC[-1][1]+avgC[1][1])/2
            #new_time = time-max_time
            new_time = time
            new_avgC = avgC-offset
            #new_trace.append((new_time, avgC))
            new_trace.append(new_time)
            new_trace_2.append(new_avgC)
            h2_trace.Fill(time - max_time, (avgC - offset))
        for i in range (1, 9):
            this_guess = i*10
            for j in range(len(new_trace)):
                if new_trace[j] > this_guess:
                    prev_time = new_trace[j-1]
                    prev_avgC = new_trace_2[j-1]
                    if prev_avgC > 200:
                        if new_trace_2[j] < 200:
                            fraction = (200 - prev_avgC)/(new_trace_2[j]-prev_avgC)
                            kick_time = prev_time + dt*fraction
                            #kick_time = max_time
                            for k in range(len(new_trace)):
                                t_time = new_trace[k]
                                t_avgC = new_trace_2[k] #- c[i-1]
                                if t_time >= kick_time - 0.5 and t_time < kick_time + 3:
                                    h2_trace_kicks.Fill(t_time-time_of_max[i-1], t_avgC)
                                        #print(t_avgC)
                                        
                                        #print(c[i-1])
        #print(len(new_trace))
        fi += 1
        
    c_h2_trace_kicks = ROOT.TCanvas()
    #h2_trace_kicks.GetYaxis().SetRangeUser(-160, 900)
    h2_trace_kicks.GetXaxis().SetRangeUser(0, 1.0)
    h2_trace_kicks.GetYaxis().SetRangeUser(-100.0, 100.0)
    h2_trace_kicks.Draw("colz")
    if SaveFigs:
        c_h2_trace_kicks.SaveAs(os.path.join(output_folder, "eddy_for2mean_kicks.png"))


    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    #h2_trace.GetXaxis().SetRangeUser(0, 0.2)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "eddy_for2mean.png"))

        
    fout = ROOT.TFile(os.path.join(output_folder, "eddy_for2mean.root"), "recreate")
    h2_trace.Write()
    h2_trace_kicks.Write()
    fout.Close()
    

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_1()


# In[4]:


import os
import ROOT

def plot_1(folder="/home/nicolo/FD_R0_analyses/EddyCurrents/SD_R1/SD_R1_for3mean",
           output_folder="/home/nicolo/FD_R0_analyses/test/analysis_eddy"):

    SaveFigs = True
    
    Npoints = 204400
    tstart = -0.2
    tend = 104.4528
    dt = (tend - tstart) / Npoints
    #dt=0.000512
    c=[0.44924800725720093, 1.5315427682288465, -0.015387108715039649, -0.24407205059385786, -0.6861436070837124,
           -0.6400115983755049, -1.1532537968331094, -1.4067210270901183]
    
    
    h2_trace = ROOT.TH2F("h2_trace", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)
    h2_trace_kicks = ROOT.TH2F("h2_trace_kicks", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        new_trace = []
        new_trace_2 = []
        time_of_max = []
        
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                
                
                time, A, B, C_str, D, avgC_str = line.split(',')
                time = float(time)
                A = float(A)
                B = float(B)
                if C_str.strip() == '∞':
                    C = float(999.0)
                else:
                    C = float(C_str)    
                D = float(D)
                if avgC_str.strip() == '∞':
                    avgC = float(999.0)
                else:
                    avgC = float(avgC_str)
                    
                    
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if avgC > 990000:
                    if time > j*10 + 1 and time < (j+1)*10 + 1:
                        time_of_max.append(time)
                        j+=1
                        '''print(time)
                        print(avgC)'''
                if time < 5:
                    offset += avgC
                    off += 1
                    j=0
                

        offset = offset / (1.0 * off)
        #h2_max.Fill(max_time, max_amplitude)
        
        for time, avgC in trace:
            if avgC == 0:
                avgC = (avgC[-1][1]+avgC[1][1])/2
            #new_time = time-max_time
            new_time = time
            new_avgC = avgC-offset
            #new_trace.append((new_time, avgC))
            new_trace.append(new_time)
            new_trace_2.append(new_avgC)
            h2_trace.Fill(time - max_time, (avgC - offset))
        for i in range (1, 9):
            this_guess = i*10
            for j in range(len(new_trace)):
                if new_trace[j] > this_guess:
                    prev_time = new_trace[j-1]
                    prev_avgC = new_trace_2[j-1]
                    if prev_avgC > 200:
                        if new_trace_2[j] < 200:
                            fraction = (200 - prev_avgC)/(new_trace_2[j]-prev_avgC)
                            kick_time = prev_time + dt*fraction
                            #kick_time = max_time
                            for k in range(len(new_trace)):
                                t_time = new_trace[k]
                                t_avgC = new_trace_2[k] #- c[i-1]
                                if t_time >= kick_time - 0.5 and t_time < kick_time + 3:
                                    h2_trace_kicks.Fill(t_time-time_of_max[i-1], t_avgC)
                                        #print(t_avgC)
                                        
                                        #print(c[i-1])
        #print(len(new_trace))
        fi += 1
        
    c_h2_trace_kicks = ROOT.TCanvas()
    #h2_trace_kicks.GetYaxis().SetRangeUser(-160, 900)
    h2_trace_kicks.GetXaxis().SetRangeUser(0, 1.0)
    h2_trace_kicks.GetYaxis().SetRangeUser(-100.0, 100.0)
    h2_trace_kicks.Draw("colz")
    if SaveFigs:
        c_h2_trace_kicks.SaveAs(os.path.join(output_folder, "eddy_for3mean_kicks.png"))


    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "eddy_for3mean.png"))

        
    fout = ROOT.TFile(os.path.join(output_folder, "eddy_for3mean.root"), "recreate")
    h2_trace.Write()
    h2_trace_kicks.Write()
    fout.Close()
    

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_1()


# In[5]:


import os
import ROOT

def plot_1(folder="/home/nicolo/FD_R0_analyses/EddyCurrents/SD_R1/SD_R1_for4mean",
           output_folder="/home/nicolo/FD_R0_analyses/test/analysis_eddy"):

    SaveFigs = True
    
    Npoints = 204400
    tstart = -0.2
    tend = 104.4528
    dt = (tend - tstart) / Npoints
    #dt=0.000512
    c=[0.44924800725720093, 1.5315427682288465, -0.015387108715039649, -0.24407205059385786, -0.6861436070837124,
           -0.6400115983755049, -1.1532537968331094, -1.4067210270901183]
    

    
    h2_trace = ROOT.TH2F("h2_trace", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)
    h2_trace_kicks = ROOT.TH2F("h2_trace_kicks", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        new_trace = []
        new_trace_2 = []
        time_of_max = []
        
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0
        j = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                
                
                time, A, B, C_str, D, avgC_str = line.split(',')
                time = float(time)
                A = float(A)
                B = float(B)
                if C_str.strip() == '∞':
                    C = float(999.0)
                else:
                    C = float(C_str)    
                D = float(D)
                if avgC_str.strip() == '∞':
                    avgC = float(999.0)
                else:
                    avgC = float(avgC_str)
                    
                    
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if avgC > 990000:
                    if time > j*10 + 1 and time < (j+1)*10 + 1:
                        time_of_max.append(time)
                        j+=1
                        '''print(time)
                        print(avgC)'''
                if time < 5:
                    offset += avgC
                    off += 1
                    j=0
                

        offset = offset / (1.0 * off)
        #h2_max.Fill(max_time, max_amplitude)
        
        for time, avgC in trace:
            if avgC == 0:
                avgC = (avgC[-1][1]+avgC[1][1])/2
            #new_time = time-max_time
            new_time = time
            new_avgC = avgC-offset
            #new_trace.append((new_time, avgC))
            new_trace.append(new_time)
            new_trace_2.append(new_avgC)
            h2_trace.Fill(time - max_time, (avgC - offset))
        for i in range (1, 9):
            this_guess = i*10
            for j in range(len(new_trace)):
                if new_trace[j] > this_guess:
                    prev_time = new_trace[j-1]
                    prev_avgC = new_trace_2[j-1]
                    if prev_avgC > 200:
                        if new_trace_2[j] < 200:
                            fraction = (200 - prev_avgC)/(new_trace_2[j]-prev_avgC)
                            kick_time = prev_time + dt*fraction
                            #kick_time = max_time
                            for k in range(len(new_trace)):
                                t_time = new_trace[k]
                                t_avgC = new_trace_2[k] #- c[i-1]
                                if t_time >= kick_time - 0.5 and t_time < kick_time + 3:
                                    h2_trace_kicks.Fill(t_time-time_of_max[i-1], t_avgC)
                                        #print(t_avgC)
                                        
                                        #print(c[i-1])
        #print(len(new_trace))
        fi += 1
        
    c_h2_trace_kicks = ROOT.TCanvas()
    #h2_trace_kicks.GetYaxis().SetRangeUser(-160, 900)
    h2_trace_kicks.GetXaxis().SetRangeUser(0, 1.0)
    h2_trace_kicks.GetYaxis().SetRangeUser(-100.0, 100.0)
    h2_trace_kicks.Draw("colz")
    if SaveFigs:
        c_h2_trace_kicks.SaveAs(os.path.join(output_folder, "eddy_for4mean_kicks.png"))


    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "eddy_for4mean.png"))

        
    fout = ROOT.TFile(os.path.join(output_folder, "eddy_for4mean.root"), "recreate")
    h2_trace.Write()
    h2_trace_kicks.Write()
    #print(time_of_max)
    fout.Close()
    

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_1()


# In[6]:


import os
import ROOT

def plot_1(folder="/home/nicolo/FD_R0_analyses/EddyCurrents/SD_R1/SD_R1_for5mean",
           output_folder="/home/nicolo/FD_R0_analyses/test/analysis_eddy"):

    SaveFigs = True
    
    Npoints = 204400
    tstart = -0.2
    tend = 104.4528
    dt = (tend - tstart) / Npoints
    #dt=0.000512
    
    
    c=[0.44924800725720093, 1.5315427682288465, -0.015387108715039649, -0.24407205059385786, -0.6861436070837124,
           -0.6400115983755049, -1.1532537968331094, -1.4067210270901183]

    
    h2_trace = ROOT.TH2F("h2_trace", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)
    h2_trace_kicks = ROOT.TH2F("h2_trace_kicks", "eddy trace", Npoints, tstart, tend, 1060, -160, 900)

    dir_files = os.listdir(folder)
    fi = 0
    for dirfile in dir_files:
        file_path = os.path.join(folder, dirfile)

        if not os.path.isfile(file_path):
            continue

        print("Reading file", dirfile)

        trace = []
        new_trace = []
        new_trace_2 = []
        time_of_max = []
        
        max_time = 0
        max_amplitude = 0
        offset = 0
        off = 0
        j = 0

        with open(file_path, 'r') as file:
            for _ in range(3):
                file.readline()

            for line in file:
                
                
                time, A, B, C_str, D, avgC_str = line.split(',')
                time = float(time)
                A = float(A)
                B = float(B)
                if C_str.strip() == '∞':
                    C = float(999.0)
                else:
                    C = float(C_str)    
                D = float(D)
                if avgC_str.strip() == '∞':
                    avgC = float(999.0)
                else:
                    avgC = float(avgC_str)
                    
                    
                avgC = avgC * 1000
                trace.append((time, avgC))
                if avgC > max_amplitude:
                    max_amplitude = avgC
                    max_time = time
                if avgC > 990000:
                    if time > j*10 + 1 and time < (j+1)*10 + 1:
                        time_of_max.append(time)
                        j+=1
                        '''print(time)
                        print(avgC)'''
                if time < 5:
                    offset += avgC
                    off += 1
                    j=0
                

        offset = offset / (1.0 * off)
        #h2_max.Fill(max_time, max_amplitude)
        
        for time, avgC in trace:
            if avgC == 0:
                avgC = (avgC[-1][1]+avgC[1][1])/2
            #new_time = time-max_time
            new_time = time
            new_avgC = avgC-offset
            #new_trace.append((new_time, avgC))
            new_trace.append(new_time)
            new_trace_2.append(new_avgC)
            h2_trace.Fill(time - max_time, (avgC - offset))
        for i in range (1, 9):
            this_guess = i*10
            for j in range(len(new_trace)):
                if new_trace[j] > this_guess:
                    prev_time = new_trace[j-1]
                    prev_avgC = new_trace_2[j-1]
                    if prev_avgC > 200:
                        if new_trace_2[j] < 200:
                            fraction = (200 - prev_avgC)/(new_trace_2[j]-prev_avgC)
                            kick_time = prev_time + dt*fraction
                            #kick_time = max_time
                            for k in range(len(new_trace)):
                                t_time = new_trace[k]
                                t_avgC = new_trace_2[k] #- c[i-1]
                                if t_time >= kick_time - 0.5 and t_time < kick_time + 3:
                                    h2_trace_kicks.Fill(t_time-time_of_max[i-1], t_avgC)
                                        #print(t_avgC)
                                        
                                        #print(c[i-1])
        #print(len(new_trace))
        fi += 1
        
    c_h2_trace_kicks = ROOT.TCanvas()
    #h2_trace_kicks.GetYaxis().SetRangeUser(-160, 900)
    h2_trace_kicks.GetXaxis().SetRangeUser(0, 1.0)
    h2_trace_kicks.GetYaxis().SetRangeUser(-100.0, 100.0)
    h2_trace_kicks.Draw("colz")
    if SaveFigs:
        c_h2_trace_kicks.SaveAs(os.path.join(output_folder, "eddy_for5mean_kicks.png"))


    c_h2_trace = ROOT.TCanvas()
    h2_trace.GetYaxis().SetRangeUser(-160, 900)
    h2_trace.Draw("colz")
    if SaveFigs:
        c_h2_trace.SaveAs(os.path.join(output_folder, "eddy_for5mean.png"))

        
    fout = ROOT.TFile(os.path.join(output_folder, "eddy_for5mean.root"), "recreate")
    h2_trace.Write()
    h2_trace_kicks.Write()
    fout.Close()
    

ROOT.gROOT.SetBatch(ROOT.kTRUE)  # Run in batch mode
plot_1()


# In[7]:


import subprocess

input_files = [
    "/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_for1mean.root",
    "/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_for2mean.root",
    "/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_for3mean.root",
    "/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_for4mean.root",
    "/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_for5mean.root",
]

output_file = "/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_finalmean_R1.root"


hadd_command = ["hadd", "-f", output_file] + input_files


try:
    subprocess.run(hadd_command, check=True)
    print("Concatenazione completata con successo!")
except subprocess.CalledProcessError as e:
    print(f"Errore durante l'esecuzione di hadd: {e}")



# In[9]:


import ROOT
import os


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_finalmean_R1.root")
filein.cd()
h2_trace = filein.Get("h2_trace")


g_profile = h2_trace.ProfileX('trace')
g_profile.Sumw2()

c = ROOT.TCanvas("canvas", "TProfile Example", 800, 600)
g_profile.Draw()
c.Draw()

#g_profile.GetXaxis().SetRangeUser(0, 100)
#h2_trace.GetXaxis().SetRangeUser(0., 0.025)
h2_trace.GetYaxis().SetRangeUser(-60.0, 900.0)
a = ROOT.TCanvas("canvas_a", "TProfile_Example", 800, 600)
h2_trace.Draw('colz')
a.Draw()


output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_eddy"
output_file_png = os.path.join(output_folder, "eddy_R1_plot.png")
output_file_png_h2 = os.path.join(output_folder, "eddy_R1_plot_h2.png")
c.SaveAs(output_file_png)
a.SaveAs(output_file_png_h2)

output_file_root = os.path.join(output_folder, "eddy_R1_plot.root")
fout = ROOT.TFile(output_file_root, "recreate")
g_profile.Write()
h2_trace.Write()
fout.Close()

print(g_profile.GetBinError(12))
print(g_profile.GetBinContent(12))


# In[1]:


import ROOT
import numpy as np
import matplotlib.pyplot as plt
import array

filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


x_min = 0
x_max = 2


bin_x_min = g_trace.FindBin(x_min)
bin_x_max = g_trace.FindBin(x_max)


x_values = []
y_values = []

for bin in range(bin_x_min, bin_x_max + 1):
    x_values.append(g_trace.GetBinCenter(bin))
    y_values.append(g_trace.GetBinContent(bin))
    
#print(x_values)
#print(y_values)


fft_result = np.fft.fft(y_values)
#print(fft_result)
freq = np.fft.fftfreq(len(x_values), d=x_values[1] - x_values[0])
#freq = np.fft.fftfreq(len(x_values), d=(x_values[1] - x_values[0])/10)
#print(freq)
magnitude = np.abs(fft_result)
#print(magnitude)


plt.plot(freq, magnitude)
#plt.xlim(0,np.max(freq))
plt.grid()
plt.xlim(1,1000)
plt.ylim(0)
plt.xlabel('Frequency(KHz)')
plt.ylabel('Magnitude')
plt.title('FFT')
plt.xscale('log')
plt.show()
print(len(freq))    


hist_magnitude = ROOT.TH1D("fft_magnitude", "FFT Magnitude;Frequency [kHz];Magnitude", len(freq) // 2, 0, np.max(freq) / 2)
for i in range(len(freq)):
    if freq[i] >= 0:
        #bin_index = hist_magnitude.FindBin(freq[i])
        hist_magnitude.Fill(freq[i], magnitude[i])
        #hist_magnitude.SetBinContent(bin_index, magnitude[i])
        

c_fft = ROOT.TCanvas()
ROOT.gPad.SetLogx()
hist_magnitude.Draw()



output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_eddy"

c_fft.SaveAs(f"{output_folder}/FFT_Magnitude.png")
c_fft.SaveAs(f"{output_folder}/FFT_Magnitude.root")
c_fft.Write()

filein.Close()

'''#plot in an interval i'm interested in

start_freq = 10
end_freq = 100
indices_of_interest = np.where((freq >= start_freq) & (freq <= end_freq))[0]
magnitude_of_interest = magnitude[indices_of_interest]
max_magnitude = np.max(magnitude_of_interest)
index_of_max = np.argmax(magnitude_of_interest)
frequency_at_max = freq[indices_of_interest[index_of_max]]
plt.plot(freq[indices_of_interest], magnitude_of_interest)
plt.grid()
plt.xlim(10, 50)
plt.ylim(0)
plt.xlabel('Frequency (KHz)')
plt.ylabel('Magnitude')
plt.title('FFT (Intervallo di Interesse)')
plt.show()
print("max_freq", frequency_at_max)'''







# In[10]:


#Tprofile e TH2 totale degli 8 kick uno sopra all'altro

import ROOT
import os


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_finalmean_R1.root")
filein.cd()
h2_trace = filein.Get("h2_trace_kicks")


g_profile = h2_trace.ProfileX('trace_kicks')
g_profile.Sumw2()

c = ROOT.TCanvas("canvas", "TProfile Example", 800, 600)
g_profile.Draw()
c.Draw()

h2_trace.GetXaxis().SetRangeUser(-0.06, 1)
h2_trace.GetYaxis().SetRangeUser(-100.0, 100.0)
a = ROOT.TCanvas("canvas_a", "TProfile_Example", 800, 600)
h2_trace.Draw('colz')
a.Draw()


output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_eddy"
output_file_png = os.path.join(output_folder, "eddy_R1_plot_allkickinone.png")
output_file_png_h2 = os.path.join(output_folder, "eddy_R1_plot_h2_allkickinone.png")
c.SaveAs(output_file_png)
a.SaveAs(output_file_png_h2)

output_file_root = os.path.join(output_folder, "eddy_R1_plot_allkickinone.root")
fout = ROOT.TFile(output_file_root, "recreate")
g_profile.Write()
h2_trace.Write()
fout.Close()

print(g_profile.GetBinError(124))
print(g_profile.GetBinContent(124))


# In[ ]:




