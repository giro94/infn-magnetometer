Eddy comparison: Used to compare the 8 bunches in eddy currents analysis
Eddy PyRoot R1: Used to plot the eddy currents trace, to make mean consistency plots, to compute the average of the 8 kicks and to make the FFT of the signal
Fit_minuit: Used to fit the eddy currents trace and the average kick, to plot rhe residual adn to compute the residual FFT
FFT.c : Code used to compute the FFT in ROOT (written in c++)
Plot aligned kicks: Code used to plot the main kicks and to compare each other.


Ask me if you need something or something is written badly or not understable :)
Nicolò Rossolino
email: nicolorossolino@gmail.com
telephone number: +39 3495385930
