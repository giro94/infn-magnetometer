#!/usr/bin/env python
# coding: utf-8

# In[1]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(0)  
end_bin = g_trace.FindBin(1) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_1Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

print(g_trace.FindBin(-0.2))
filein.Close()


# In[2]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(10)  
end_bin = g_trace.FindBin(11) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_2Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[3]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(20)  
end_bin = g_trace.FindBin(21) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_3Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[4]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(30)  
end_bin = g_trace.FindBin(31) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_4Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[5]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(40)  
end_bin = g_trace.FindBin(41) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_5Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[6]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(50)  
end_bin = g_trace.FindBin(51) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_6Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[7]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(60)  
end_bin = g_trace.FindBin(61) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_7Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[8]:


import ROOT


filein = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_R1_plot.root")
filein.cd()
g_trace = filein.Get('trace')


numBins = 1954
xMin = 0
xMax = 1


profile = ROOT.TH1D('profile_new', 'Eddy_FirstKick', numBins, xMin, xMax)


start_bin = g_trace.FindBin(70)  
end_bin = g_trace.FindBin(71) 

for bin_index in range(start_bin, end_bin + 1):
    bin_content = g_trace.GetBinContent(bin_index)
    bin_error = g_trace.GetBinError(bin_index)
    profile.SetBinContent(bin_index - start_bin + 1, bin_content)
    profile.SetBinError(bin_index - start_bin + 1, bin_error)
        

canvas = ROOT.TCanvas("c", "kick", 800, 600)
profile.Draw() 

output_file = ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_8Kick_profile.root", "RECREATE")
profile.Write()
canvas.Write()
output_file.Close()

filein.Close()


# In[9]:


import ROOT
import os

# confronto il kick nella configurazione R0 con quello nella configurazione R1 dopo il secondo giro di misure di R0

def eddy_comparison(output_folder = "/home/nicolo/FD_R0_analyses/test/analysis_eddy"):

    SaveFigs = True;

    filein1=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_1Kick_profile.root")
    filein1.cd()
    g_trace1 = filein1.Get("profile_new")

    filein2=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_2Kick_profile.root")
    filein2.cd()
    g_trace2 = filein2.Get("profile_new")

    filein3=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_3Kick_profile.root")
    filein3.cd()
    g_trace3 = filein3.Get("profile_new")

    filein4=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_4Kick_profile.root")
    filein4.cd()
    g_trace4 = filein4.Get("profile_new")
    
    filein5=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_5Kick_profile.root")
    filein5.cd()
    g_trace5 = filein5.Get("profile_new")

    filein6=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_6Kick_profile.root")
    filein6.cd()
    g_trace6 = filein6.Get("profile_new")
    
    filein7=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_7Kick_profile.root")
    filein7.cd()
    g_trace7 = filein7.Get("profile_new")

    filein8=ROOT.TFile("/home/nicolo/FD_R0_analyses/test/analysis_eddy/eddy_8Kick_profile.root")
    filein8.cd()
    g_trace8 = filein8.Get("profile_new")
    
    
    b_trace = ROOT.TCanvas()
    
    g_trace1.GetYaxis().SetRangeUser(-180,900)
    g_trace1.SetMarkerColor(ROOT.kBlack)
    g_trace1.SetLineColor(ROOT.kBlack)
    g_trace1.SetLineWidth(2)
    g_trace1.Draw("")    #con E nella parentesi di draw si mettono gli errori
    
    g_trace2.SetMarkerColor(ROOT.kRed)
    g_trace2.SetLineColor(ROOT.kRed)
    g_trace2.SetLineWidth(2)
    g_trace2.Draw("SAME")  
   
    g_trace3.SetMarkerColor(ROOT.kYellow)
    g_trace3.SetLineColor(ROOT.kYellow)
    g_trace3.SetLineWidth(2)
    g_trace3.Draw("SAME") 
    
    g_trace4.SetMarkerColor(ROOT.kPink)
    g_trace4.SetLineColor(ROOT.kPink)
    g_trace4.SetLineWidth(2)
    g_trace4.Draw("SAME")
    
    g_trace5.SetMarkerColor(ROOT.kGreen)
    g_trace5.SetLineColor(ROOT.kGreen)
    g_trace5.SetLineWidth(2)
    g_trace5.Draw("SAME") 
    
    g_trace6.SetMarkerColor(ROOT.kCyan)
    g_trace6.SetLineColor(ROOT.kCyan)
    g_trace6.SetLineWidth(2)
    g_trace6.Draw("SAME")  
    
    g_trace7.SetMarkerColor(ROOT.kViolet)
    g_trace7.SetLineColor(ROOT.kViolet)
    g_trace7.SetLineWidth(2)
    g_trace7.Draw("SAME") 
    
    g_trace8.SetMarkerColor(ROOT.kBlue)
    g_trace8.SetLineColor(ROOT.kBlue)
    g_trace8.SetLineWidth(2)
    g_trace8.Draw("SAME")  
    
    
    
    xl1=0.05
    yl1=0.75
    xl2=xl1+0.3
    yl2=yl1+0.125
    leg = ROOT.TLegend(xl1,yl1,xl2,yl2)
    leg.AddEntry(g_trace1,"EddyCurrents_1Kick","l")
    leg.AddEntry(g_trace2,"EddyCurrents_2Kick","l")
    leg.AddEntry(g_trace3,"EddyCurrents_3Kick","l")
    leg.AddEntry(g_trace4,"EddyCurrents_4Kick","l")
    leg.AddEntry(g_trace5,"EddyCurrents_5Kick","l")
    leg.AddEntry(g_trace6,"EddyCurrents_6Kick","l")
    leg.AddEntry(g_trace7,"EddyCurrents_7Kick","l")
    leg.AddEntry(g_trace8,"EddyCurrents_8Kick","l")
    leg.Draw()
    b_trace.Draw()
    if SaveFigs:
        b_trace.SaveAs(os.path.join(output_folder, "EddyCurrents_AllKickInOne.png"))
        b_trace.SaveAs(os.path.join(output_folder, "EddyCurrents_AllKickInOne.root"))
  
  
    fout = ROOT.TFile(os.path.join(output_folder, "EddyCurrents_AllKickInOne.root"), "recreate")
    g_trace1.Write()
    g_trace2.Write()
    g_trace3.Write()
    g_trace4.Write()
    g_trace5.Write()
    g_trace6.Write()
    g_trace7.Write()
    g_trace8.Write()
    b_trace.Write()
    fout.Close()
eddy_comparison()


# In[ ]:




